#pragma once
#include "Curve2d.h"
namespace lesson_10
{
	class Arc2d : public Curve2d
	{
	public:
		Arc2d(const Point2D StartPoint, const Point2D EndPoint, const Point2D CentralPoint);
		Arc2d();
		~Arc2d();
		//void CentrPoint(int x, int y)
		//{
		//	CentralPoint = new Point2D(x, y);
		//}
		int radius();
		double angle();
	protected:
		Point2D CentralPoint;
	};
}
